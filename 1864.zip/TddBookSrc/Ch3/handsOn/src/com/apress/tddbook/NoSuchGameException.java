package com.apress.tddbook;

public class NoSuchGameException extends Exception
{
}
