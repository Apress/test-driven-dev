package com.apress.tddbook;


public class BadGameIndexException extends Exception {

}
