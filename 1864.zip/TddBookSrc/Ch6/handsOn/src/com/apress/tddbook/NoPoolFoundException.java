package com.apress.tddbook;

public class NoPoolFoundException extends Exception
{

}
