package com.apress.tddbook;

public class PicksNotFoundException extends Exception
{
    
}
